import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'auth/auth_screens.dart';
import 'data/store.dart';
import 'data/sync.dart';
import 'firebase_options.dart';
import 'ui/home_shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  } catch (e) {
    runApp(_SetupErrorApp('$e'));
    return;
  }
  // The app keeps its own compact local copy, so Firestore's cache would only duplicate it.
  FirebaseFirestore.instance.settings = const Settings(persistenceEnabled: false);
  await FirebaseAuth.instance.setLanguageCode('pl');
  runApp(const TrainerApp());
}

final _theme = ThemeData(colorSchemeSeed: const Color(0xFF10B981), brightness: Brightness.dark, useMaterial3: true);

MaterialApp _materialApp({Key? key, required Widget home}) => MaterialApp(
      key: key,
      title: 'AI Trainer',
      debugShowCheckedModeBanner: false,
      theme: _theme,
      locale: const Locale('pl'),
      supportedLocales: const [Locale('pl'), Locale('en')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      home: home,
    );

class TrainerApp extends StatefulWidget {
  /// Skips Firebase and runs on this store only (tests).
  final AppStore? offlineStore;
  const TrainerApp({super.key, this.offlineStore});

  @override
  State<TrainerApp> createState() => _TrainerAppState();
}

class _TrainerAppState extends State<TrainerApp> {
  StreamSubscription<User?>? _authSub;
  bool _authKnown = false;
  User? _user;
  AppStore? _store;
  SyncService? _sync;

  @override
  void initState() {
    super.initState();
    if (widget.offlineStore != null) {
      _store = widget.offlineStore;
      _authKnown = true;
      return;
    }
    _authSub = FirebaseAuth.instance.authStateChanges().listen(_onUser);
  }

  Future<void> _onUser(User? user) async {
    if (user?.uid == _user?.uid && _authKnown) return;
    _sync?.dispose();
    _sync = null;
    _store = null;
    _user = user;
    _authKnown = true;
    setState(() {});
    if (user == null) return;
    final store = await AppStore.load(user.uid);
    if (!mounted || _user?.uid != user.uid) return;
    final sync = SyncService(store, user)..start();
    setState(() {
      _store = store;
      _sync = sync;
    });
  }

  @override
  void dispose() {
    _authSub?.cancel();
    _sync?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final store = _store;
    if (!_authKnown || (_user != null && store == null)) {
      return _materialApp(home: const Scaffold(body: Center(child: CircularProgressIndicator())));
    }
    if (store == null) return _materialApp(home: const LoginScreen());
    return StoreScope(
      store: store,
      child: SyncScope(
        sync: _sync,
        child: _materialApp(key: ValueKey(_user?.uid), home: const HomeShell()),
      ),
    );
  }
}

class _SetupErrorApp extends StatelessWidget {
  final String error;
  const _SetupErrorApp(this.error);

  @override
  Widget build(BuildContext context) => _materialApp(
        home: Scaffold(
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Icon(Icons.cloud_off, size: 56, color: Colors.amber),
                const SizedBox(height: 16),
                const Text('Firebase nie jest skonfigurowany', style: TextStyle(fontSize: 20)),
                const SizedBox(height: 12),
                SelectableText(error, textAlign: TextAlign.center),
              ]),
            ),
          ),
        ),
      );
}
