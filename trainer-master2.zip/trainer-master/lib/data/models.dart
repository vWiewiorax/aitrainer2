import 'package:flutter/painting.dart';

enum ExerciseKind {
  weightReps('Ciężar i powtórzenia'),
  bodyweight('Masa ciała + powtórzenia'),
  duration('Czas'),
  cardio('Dystans i czas');

  final String label;
  const ExerciseKind(this.label);
}

enum MuscleCategory {
  chest('Klatka piersiowa', Color(0xFFEF4444)),
  back('Plecy', Color(0xFF3B82F6)),
  legs('Nogi', Color(0xFF22C55E)),
  glutes('Pośladki', Color(0xFFEC4899)),
  shoulders('Barki', Color(0xFFF59E0B)),
  biceps('Biceps', Color(0xFF8B5CF6)),
  triceps('Triceps', Color(0xFF06B6D4)),
  forearms('Przedramiona', Color(0xFFA8A29E)),
  core('Brzuch', Color(0xFFEAB308)),
  calves('Łydki', Color(0xFF14B8A6)),
  cardio('Cardio', Color(0xFFF97316));

  final String label;
  final Color color;
  const MuscleCategory(this.label, this.color);
}

/// Movement pattern used by the camera technique check when the engine has no dedicated definition.
enum TechniquePattern {
  squat('Przysiad (kąt kolana)'),
  legPress('Wypychanie nogami (kąt kolana)'),
  lunge('Wykrok (kąt kolana)'),
  hinge('Skłon w biodrach (kąt biodra)'),
  hipExtension('Wyprost bioder (kąt biodra)'),
  kneeExtension('Prostowanie kolan'),
  kneeFlexion('Uginanie kolan'),
  press('Wyciskanie (kąt łokcia)'),
  pull('Przyciąganie (kąt łokcia)'),
  curl('Uginanie ramion (kąt łokcia)'),
  elbowExtension('Prostowanie ramion (kąt łokcia)'),
  raise('Unoszenie ramion (kąt barku)'),
  pullover('Ściąganie prostymi rękami (kąt barku)'),
  crunch('Spięcie brzucha (kąt biodra)'),
  legRaise('Unoszenie nóg (kąt biodra)'),
  calf('Wspięcia na palce (kąt skokowy)'),
  hold('Pozycja statyczna (linia ciała)'),
  tracking('Tylko śledzenie sylwetki');

  final String label;
  const TechniquePattern(this.label);
}

T enumByName<T extends Enum>(List<T> values, Object? name, T fallback) {
  for (final v in values) {
    if (v.name == name) return v;
  }
  return fallback;
}

class Exercise {
  final String id;
  final String name;
  final MuscleCategory category;
  final ExerciseKind kind;
  final String equipment;
  final List<String> muscles;
  final TechniquePattern pattern;

  /// Id of a full engine definition (technique rules), when one exists.
  final String? engineId;
  final String? videoUrl;

  /// Exercise-specific instructions; the shared template is used when null.
  final List<String>? steps;
  final bool custom;

  const Exercise(
    this.id,
    this.name,
    this.category,
    this.kind,
    this.equipment,
    this.muscles,
    this.pattern, {
    this.engineId,
    this.videoUrl,
    this.steps,
    this.custom = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'category': category.name,
        'kind': kind.name,
        'equipment': equipment,
        'muscles': muscles,
        'pattern': pattern.name,
      };

  factory Exercise.fromJson(Map<String, dynamic> j) => Exercise(
        j['id'] as String,
        j['name'] as String,
        enumByName(MuscleCategory.values, j['category'], MuscleCategory.chest),
        enumByName(ExerciseKind.values, j['kind'], ExerciseKind.weightReps),
        j['equipment'] as String? ?? '',
        List<String>.from(j['muscles'] as List? ?? const []),
        enumByName(TechniquePattern.values, j['pattern'], TechniquePattern.tracking),
        custom: true,
      );
}

class WorkoutSet {
  final String id;
  final String exerciseId;

  /// Day key, `yyyy-MM-dd`.
  final String date;
  final int createdAt;

  /// Last edit time; decides which copy wins when devices merge.
  final int updatedAt;
  final double weight;
  final int reps;
  final int seconds;
  final double distance;

  const WorkoutSet({
    required this.id,
    required this.exerciseId,
    required this.date,
    required this.createdAt,
    int? updatedAt,
    this.weight = 0,
    this.reps = 0,
    this.seconds = 0,
    this.distance = 0,
  }) : updatedAt = updatedAt ?? createdAt;

  double get volume => weight * reps;

  WorkoutSet copyWith({double? weight, int? reps, int? seconds, double? distance, int? updatedAt}) => WorkoutSet(
        id: id,
        exerciseId: exerciseId,
        date: date,
        createdAt: createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        weight: weight ?? this.weight,
        reps: reps ?? this.reps,
        seconds: seconds ?? this.seconds,
        distance: distance ?? this.distance,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'exerciseId': exerciseId,
        'date': date,
        'createdAt': createdAt,
        if (weight != 0) 'weight': weight,
        if (reps != 0) 'reps': reps,
        if (seconds != 0) 'seconds': seconds,
        if (distance != 0) 'distance': distance,
      };

  factory WorkoutSet.fromJson(Map<String, dynamic> j) => WorkoutSet(
        id: j['id'] as String,
        exerciseId: j['exerciseId'] as String,
        date: j['date'] as String,
        createdAt: (j['createdAt'] as num).toInt(),
        weight: (j['weight'] as num?)?.toDouble() ?? 0,
        reps: (j['reps'] as num?)?.toInt() ?? 0,
        seconds: (j['seconds'] as num?)?.toInt() ?? 0,
        distance: (j['distance'] as num?)?.toDouble() ?? 0,
      );
}

int compareSets(WorkoutSet a, WorkoutSet b) {
  final d = a.date.compareTo(b.date);
  return d != 0 ? d : a.createdAt.compareTo(b.createdAt);
}

/// One weekday of the training split; no exercises means a rest day.
class SplitDay {
  final String name;
  final List<String> exerciseIds;
  const SplitDay(this.name, this.exerciseIds);

  bool get isRest => exerciseIds.isEmpty;

  Map<String, dynamic> toJson() => {'name': name, 'exerciseIds': exerciseIds};

  factory SplitDay.fromJson(Map<String, dynamic> j) =>
      SplitDay(j['name'] as String? ?? '', List<String>.from(j['exerciseIds'] as List? ?? const []));
}
