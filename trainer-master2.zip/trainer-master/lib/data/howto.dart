import 'package:trainer_engine/trainer_engine.dart';

import 'models.dart';

class HowTo {
  final List<String> steps;
  final List<String> tips;
  final List<String> mistakes;
  final String breathing;
  const HowTo(this.steps, this.tips, this.mistakes, this.breathing);
}

/// Shared instruction template; exercise-specific [Exercise.steps] and engine checkpoints/rules override parts of it.
HowTo howToFor(Exercise ex, ExerciseDefinition def) {
  final muscles = ex.muscles.isEmpty ? 'docelowych mięśni' : ex.muscles.join(', ');
  final equipment = ex.equipment.isEmpty ? '' : ' (${ex.equipment.toLowerCase()})';
  final steps = ex.steps ??
      switch (ex.kind) {
        ExerciseKind.duration => [
            'Przygotuj miejsce$equipment i przyjmij pozycję wyjściową.',
            'Napnij brzuch i pośladki, ustaw ciało w jednej linii.',
            'Utrzymuj pozycję przez zaplanowany czas, oddychając spokojnie.',
            'Zakończ, gdy nie jesteś w stanie utrzymać poprawnej pozycji.',
          ],
        ExerciseKind.cardio => [
            'Zacznij od 5 minut spokojnej rozgrzewki.',
            'Ustal tempo, przy którym możesz utrzymać wysiłek przez cały zaplanowany czas.',
            'Utrzymuj wyprostowaną sylwetkę i równy rytm oddechu.',
            'Na koniec zwolnij na 3–5 minut, żeby się schłodzić.',
          ],
        _ => [
            'Przygotuj stanowisko$equipment i dobierz ciężar, z którym wykonasz wszystkie powtórzenia poprawnie.',
            'Przyjmij stabilną pozycję wyjściową: napięty brzuch, łopatki ustawione, stopy stabilnie na podłożu.',
            'Wykonaj ruch płynnie w pełnym zakresie, skupiając się na pracy mięśni: $muscles.',
            'Opuszczaj ciężar pod kontrolą przez ok. 2–3 sekundy, bez odbijania i szarpania.',
            'Powtórz zaplanowaną liczbę razy, utrzymując tę samą technikę w każdym powtórzeniu.',
          ],
      };
  final tips = def.keyCheckpoints.isNotEmpty
      ? def.keyCheckpoints
      : const [
          'Rozgrzej się i zrób 1–2 serie rozgrzewkowe z mniejszym ciężarem.',
          'Zwiększaj ciężar dopiero wtedy, gdy wszystkie serie są technicznie poprawne.',
          'Zapisuj każdą serię, żeby aplikacja mogła liczyć postępy i rekordy.',
        ];
  final mistakes = def.evaluationRules.isNotEmpty
      ? {for (final r in def.evaluationRules) r.label}.take(6).toList()
      : const [
          'Zbyt duży ciężar kosztem techniki',
          'Skracanie zakresu ruchu',
          'Szybkie, niekontrolowane opuszczanie',
          'Wstrzymywanie oddechu przez całą serię',
        ];
  return HowTo(steps, tips, mistakes, 'Wdech przed fazą opuszczania, wydech w trakcie największego wysiłku.');
}
