import 'models.dart';

class SplitTemplate {
  final String name;
  final String description;

  /// Monday..Sunday.
  final List<SplitDay> days;
  const SplitTemplate(this.name, this.description, this.days);
}

const _rest = SplitDay('', []);

const _push = SplitDay('Push', [
  'bench-press',
  'incline-db-press',
  'overhead-press',
  'lateral-raise',
  'triceps-pushdown',
  'overhead-triceps-extension',
]);
const _pull = SplitDay('Pull', ['deadlift', 'pull-up', 'barbell-row', 'lat-pulldown', 'face-pull', 'barbell-curl', 'hammer-curl']);
const _legs = SplitDay('Nogi', ['back-squat', 'romanian-deadlift', 'leg-press', 'lying-leg-curl', 'standing-calf-raise']);
const _upper = SplitDay('Góra', ['bench-press', 'barbell-row', 'overhead-press', 'lat-pulldown', 'db-curl', 'triceps-pushdown']);
const _lower = SplitDay('Dół', ['back-squat', 'romanian-deadlift', 'leg-press', 'seated-leg-curl', 'standing-calf-raise', 'plank']);
const _fbw = SplitDay('FBW', ['back-squat', 'bench-press', 'barbell-row', 'overhead-press', 'romanian-deadlift', 'plank']);

const splitTemplates = <SplitTemplate>[
  SplitTemplate('Push / Pull / Nogi', '6 dni, każda partia 2× w tygodniu', [_push, _pull, _legs, _push, _pull, _legs, _rest]),
  SplitTemplate('Góra / Dół', '4 dni treningowe', [_upper, _lower, _rest, _upper, _lower, _rest, _rest]),
  SplitTemplate('FBW (całe ciało)', '3 dni, idealne na start', [_fbw, _rest, _fbw, _rest, _fbw, _rest, _rest]),
  SplitTemplate('Split klasyczny', '5 dni, jedna partia dziennie', [
    SplitDay('Klatka', ['bench-press', 'incline-db-press', 'db-fly', 'chest-dips', 'cable-crossover']),
    SplitDay('Plecy', ['deadlift', 'pull-up', 'barbell-row', 'seated-cable-row', 'straight-arm-pulldown']),
    SplitDay('Nogi', ['back-squat', 'leg-press', 'romanian-deadlift', 'leg-extension', 'lying-leg-curl', 'standing-calf-raise']),
    SplitDay('Barki', ['overhead-press', 'lateral-raise', 'front-raise', 'rear-delt-fly', 'shrug']),
    SplitDay('Ramiona', ['barbell-curl', 'close-grip-bench', 'hammer-curl', 'skull-crusher', 'cable-curl', 'triceps-pushdown']),
    _rest,
    _rest,
  ]),
];
