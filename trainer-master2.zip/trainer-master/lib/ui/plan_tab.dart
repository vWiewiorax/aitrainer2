import 'package:flutter/material.dart';

import '../data/dates.dart';
import '../data/models.dart';
import '../data/split_templates.dart';
import '../data/store.dart';
import 'exercise_browser.dart';
import 'exercise_screen.dart';
import 'widgets.dart';

/// Weekly training split: one routine (or rest) per weekday.
class PlanTab extends StatelessWidget {
  const PlanTab({super.key});

  Future<void> _applyTemplate(BuildContext context, SplitTemplate t) async {
    final store = StoreScope.read(context);
    if (store.split.any((d) => !d.isRest)) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text('Wczytać „${t.name}”?'),
          content: const Text('Obecny plan tygodniowy zostanie zastąpiony.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Anuluj')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Wczytaj')),
          ],
        ),
      );
      if (ok != true) return;
    }
    store.setSplit(t.days);
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final todayWd = today().weekday;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Plan tygodniowy'),
        actions: [
          PopupMenuButton<SplitTemplate>(
            tooltip: 'Gotowe plany',
            icon: const Icon(Icons.auto_awesome),
            onSelected: (t) => _applyTemplate(context, t),
            itemBuilder: (_) => [
              for (final t in splitTemplates)
                PopupMenuItem(value: t, child: ListTile(title: Text(t.name), subtitle: Text(t.description))),
            ],
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: 7,
        itemBuilder: (context, i) {
          final wd = i + 1;
          final day = store.splitFor(wd);
          final names = [for (final id in day.exerciseIds) store.exercise(id)?.name].whereType<String>().toList();
          return Card(
            color: wd == todayWd ? Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.4) : null,
            child: ListTile(
              title: Text(weekdayNames[i] + (wd == todayWd ? ' (dziś)' : '')),
              subtitle: Text(
                day.isRest
                    ? 'Odpoczynek'
                    : '${day.name.isEmpty ? 'Trening' : day.name} · ${names.length} ćw.\n${names.join(', ')}',
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
              isThreeLine: !day.isRest,
              leading: Icon(day.isRest ? Icons.bedtime_outlined : Icons.fitness_center),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SplitDayEditor(weekday: wd))),
            ),
          );
        },
      ),
    );
  }
}

class SplitDayEditor extends StatefulWidget {
  final int weekday;
  const SplitDayEditor({super.key, required this.weekday});

  @override
  State<SplitDayEditor> createState() => _SplitDayEditorState();
}

class _SplitDayEditorState extends State<SplitDayEditor> {
  late final TextEditingController _name;
  late List<String> _ids;

  @override
  void initState() {
    super.initState();
    final day = StoreScope.read(context).splitFor(widget.weekday);
    _name = TextEditingController(text: day.name);
    _ids = List.of(day.exerciseIds);
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  void _commit() => StoreScope.read(context).setSplitDay(widget.weekday, SplitDay(_name.text.trim(), List.of(_ids)));

  Future<void> _add() async {
    final picked = await Navigator.of(context).push<List<String>>(
      MaterialPageRoute(builder: (_) => ExercisePickerScreen(multi: true, initial: _ids)),
    );
    if (picked == null) return;
    setState(() => _ids = [..._ids.where(picked.contains), ...picked.where((id) => !_ids.contains(id))]);
    _commit();
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(weekdayNames[widget.weekday - 1]),
        actions: [
          if (_ids.isNotEmpty)
            TextButton(
              onPressed: () {
                setState(() => _ids = []);
                _commit();
              },
              child: const Text('Dzień wolny'),
            ),
        ],
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextField(
            controller: _name,
            decoration: const InputDecoration(labelText: 'Nazwa treningu (np. Push, Nogi, Góra)'),
            onChanged: (_) => _commit(),
          ),
        ),
        Expanded(
          child: _ids.isEmpty
              ? const EmptyHint('Dzień wolny. Dodaj ćwiczenia, żeby zaplanować trening.', icon: Icons.bedtime_outlined)
              : ReorderableListView.builder(
                  padding: const EdgeInsets.only(bottom: 96),
                  itemCount: _ids.length,
                  onReorder: (from, to) {
                    setState(() {
                      if (to > from) to--;
                      _ids.insert(to, _ids.removeAt(from));
                    });
                    _commit();
                  },
                  itemBuilder: (context, i) {
                    final ex = store.exercise(_ids[i]);
                    return ListTile(
                      key: ValueKey(_ids[i]),
                      leading: ex == null ? const Icon(Icons.help_outline) : CategoryAvatar(ex.category),
                      title: Text(ex?.name ?? 'Usunięte ćwiczenie'),
                      subtitle: ex == null ? null : Text(ex.category.label),
                      onTap: ex == null ? null : () => openExercise(context, ex.id),
                      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                        IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () {
                            setState(() => _ids.removeAt(i));
                            _commit();
                          },
                        ),
                        ReorderableDragStartListener(index: i, child: const Icon(Icons.drag_handle)),
                      ]),
                    );
                  },
                ),
        ),
      ]),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _add,
        icon: const Icon(Icons.add),
        label: const Text('Dodaj ćwiczenia'),
      ),
    );
  }
}
