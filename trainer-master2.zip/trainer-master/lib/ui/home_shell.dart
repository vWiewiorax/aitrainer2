import 'package:flutter/material.dart';

import 'account_tab.dart';
import 'exercises_tab.dart';
import 'plan_tab.dart';
import 'progress_tab.dart';
import 'workout_tab.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) => Scaffold(
        body: IndexedStack(
          index: _index,
          children: const [WorkoutTab(), ExercisesTab(), PlanTab(), ProgressTab(), AccountTab()],
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: (i) => setState(() => _index = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.fitness_center), label: 'Trening'),
            NavigationDestination(icon: Icon(Icons.list_alt), label: 'Ćwiczenia'),
            NavigationDestination(icon: Icon(Icons.calendar_month), label: 'Plan'),
            NavigationDestination(icon: Icon(Icons.insights), label: 'Postępy'),
            NavigationDestination(icon: Icon(Icons.person), label: 'Konto'),
          ],
        ),
      );
}
