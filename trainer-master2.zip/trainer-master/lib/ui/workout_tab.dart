import 'package:flutter/material.dart';

import '../data/dates.dart';
import '../data/models.dart';
import '../data/stats.dart';
import '../data/store.dart';
import 'exercise_browser.dart';
import 'exercise_screen.dart';
import 'widgets.dart';

/// Day log: today's plan from the weekly split plus everything logged on the selected day.
class WorkoutTab extends StatefulWidget {
  const WorkoutTab({super.key});

  @override
  State<WorkoutTab> createState() => _WorkoutTabState();
}

class _WorkoutTabState extends State<WorkoutTab> {
  DateTime _date = today();

  void _shift(int days) => setState(() => _date = DateTime(_date.year, _date.month, _date.day + days));

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2015),
      lastDate: DateTime(today().year + 1, 12, 31),
    );
    if (picked != null) setState(() => _date = picked);
  }

  Future<void> _addExercise() async {
    final ex = await Navigator.of(context).push<Exercise>(MaterialPageRoute(builder: (_) => const ExercisePickerScreen()));
    if (ex != null && mounted) openExercise(context, ex.id, tab: ExerciseTab.track, date: dateKey(_date));
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final key = dateKey(_date);
    final plan = store.splitFor(_date.weekday);
    final planned = plan.exerciseIds.where((id) => store.exercise(id) != null).toList();
    final logged = store.exerciseIdsOn(key);
    final extra = logged.where((id) => !planned.contains(id) && store.exercise(id) != null).toList();
    final daySets = store.setsOn(key);
    final volume = daySets.fold(0.0, (a, s) => a + s.volume);
    final isToday = key == dateKey(today());

    return Scaffold(
      appBar: AppBar(
        title: const Text('Trening'),
        actions: [
          if (!isToday)
            IconButton(tooltip: 'Dziś', icon: const Icon(Icons.today), onPressed: () => setState(() => _date = today())),
          IconButton(tooltip: 'Wybierz dzień', icon: const Icon(Icons.calendar_month), onPressed: _pickDate),
        ],
      ),
      body: Column(children: [
        Material(
          color: Theme.of(context).colorScheme.surfaceContainerHigh,
          child: Row(children: [
            IconButton(icon: const Icon(Icons.chevron_left), onPressed: () => _shift(-1)),
            Expanded(
              child: InkWell(
                onTap: _pickDate,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Text(
                    isToday ? 'Dziś, ${formatDay(_date)}' : formatDay(_date),
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            ),
            IconButton(icon: const Icon(Icons.chevron_right), onPressed: () => _shift(1)),
          ]),
        ),
        Expanded(
          child: ListView(padding: const EdgeInsets.only(bottom: 96), children: [
            if (daySets.isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                child: Text(
                  '${logged.length} ćwiczeń · ${daySets.length} serii'
                  '${volume > 0 ? ' · objętość ${fmtNum(volume, 0)} kg' : ''}',
                  style: const TextStyle(color: Colors.white70),
                ),
              ),
            if (planned.isNotEmpty) ...[
              SectionHeader('Plan: ${plan.name.isEmpty ? weekdayNames[_date.weekday - 1] : plan.name}'),
              for (final id in planned) _ExerciseDayTile(store.exercise(id)!, key, planned: true),
            ],
            if (extra.isNotEmpty) ...[
              SectionHeader(planned.isEmpty ? 'Wykonane ćwiczenia' : 'Poza planem'),
              for (final id in extra) _ExerciseDayTile(store.exercise(id)!, key),
            ],
            if (planned.isEmpty && extra.isEmpty)
              const EmptyHint(
                'Brak ćwiczeń w tym dniu.\nDodaj ćwiczenie przyciskiem poniżej albo ustaw plan tygodniowy w zakładce Plan.',
                icon: Icons.fitness_center,
              ),
          ]),
        ),
      ]),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addExercise,
        icon: const Icon(Icons.add),
        label: const Text('Dodaj ćwiczenie'),
      ),
    );
  }
}

class _ExerciseDayTile extends StatelessWidget {
  final Exercise ex;
  final String date;
  final bool planned;
  const _ExerciseDayTile(this.ex, this.date, {this.planned = false});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final sets = store.setsOn(date, exerciseId: ex.id);
    final prs = sets.where((s) => store.stats(ex).prIds.contains(s.id)).length;
    final done = sets.isNotEmpty;
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: ListTile(
        leading: done
            ? const CircleAvatar(backgroundColor: Color(0xFF047857), child: Icon(Icons.check, color: Colors.white))
            : CategoryAvatar(ex.category),
        title: Text(ex.name),
        subtitle: Text(
          done ? sets.map((s) => formatSet(ex, s)).join(', ') : (planned ? 'Do zrobienia' : ''),
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
        trailing: prs > 0
            ? Row(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.emoji_events, color: Colors.amber),
                if (prs > 1) Text('×$prs'),
              ])
            : const Icon(Icons.chevron_right),
        onTap: () => openExercise(context, ex.id, tab: ExerciseTab.track, date: date),
      ),
    );
  }
}
