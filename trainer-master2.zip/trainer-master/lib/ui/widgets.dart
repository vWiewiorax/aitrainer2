import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../data/dates.dart';
import '../data/models.dart';

class CategoryAvatar extends StatelessWidget {
  final MuscleCategory category;
  const CategoryAvatar(this.category, {super.key});

  @override
  Widget build(BuildContext context) => CircleAvatar(
        backgroundColor: category.color.withValues(alpha: 0.22),
        child: Text(category.label[0], style: TextStyle(color: category.color, fontWeight: FontWeight.bold)),
      );
}

class SectionHeader extends StatelessWidget {
  final String text;
  final Widget? trailing;
  const SectionHeader(this.text, {super.key, this.trailing});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
        child: Row(children: [
          Expanded(
            child: Text(text,
                style: Theme.of(context)
                    .textTheme
                    .titleSmall
                    ?.copyWith(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold)),
          ),
          if (trailing != null) trailing!,
        ]),
      );
}

class EmptyHint extends StatelessWidget {
  final IconData icon;
  final String text;
  const EmptyHint(this.text, {super.key, this.icon = Icons.info_outline});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(32),
        child: Column(children: [
          Icon(icon, size: 48, color: Colors.white38),
          const SizedBox(height: 12),
          Text(text, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60)),
        ]),
      );
}

class StatCard extends StatelessWidget {
  final String label;
  final String value;
  final String? caption;
  const StatCard(this.label, this.value, {super.key, this.caption});

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 4),
            Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            if (caption != null) Text(caption!, style: const TextStyle(color: Colors.white54, fontSize: 11)),
          ]),
        ),
      );
}

/// Number input with -/+ buttons (FitNotes-style).
class NumberStepper extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final double step;
  final bool decimal;
  const NumberStepper({super.key, required this.label, required this.controller, required this.step, this.decimal = false});

  void _bump(double delta) {
    final v = math.max(0.0, (parseNum(controller.text) ?? 0) + delta);
    controller.text = decimal ? fmtNum(v) : v.round().toString();
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(color: Colors.white70)),
          Row(children: [
            IconButton.filledTonal(onPressed: () => _bump(-step), icon: const Icon(Icons.remove)),
            Expanded(
              child: TextField(
                controller: controller,
                textAlign: TextAlign.center,
                keyboardType: TextInputType.numberWithOptions(decimal: decimal),
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
                decoration: const InputDecoration(border: InputBorder.none, hintText: '0'),
              ),
            ),
            IconButton.filledTonal(onPressed: () => _bump(step), icon: const Icon(Icons.add)),
          ]),
        ]),
      );
}

class SimpleLineChart extends StatelessWidget {
  final List<(DateTime, double)> points;
  final Color color;
  const SimpleLineChart({super.key, required this.points, required this.color});

  @override
  Widget build(BuildContext context) => SizedBox(
        height: 220,
        width: double.infinity,
        child: CustomPaint(painter: _LineChartPainter(points, color, Theme.of(context).colorScheme.onSurface)),
      );
}

void _paintText(Canvas canvas, String s, Offset at, double width, TextAlign align, Color color) {
  final tp = TextPainter(
    text: TextSpan(text: s, style: TextStyle(color: color.withValues(alpha: 0.7), fontSize: 11)),
    textAlign: align,
    textDirection: TextDirection.ltr,
  )..layout(minWidth: width, maxWidth: width);
  tp.paint(canvas, at);
}

class _LineChartPainter extends CustomPainter {
  final List<(DateTime, double)> points;
  final Color color, textColor;
  _LineChartPainter(this.points, this.color, this.textColor);

  @override
  void paint(Canvas canvas, Size size) {
    if (points.isEmpty) return;
    const left = 48.0, right = 12.0, top = 8.0, bottom = 24.0;
    final w = size.width - left - right, h = size.height - top - bottom;
    var minY = points.map((p) => p.$2).reduce(math.min);
    var maxY = points.map((p) => p.$2).reduce(math.max);
    if (maxY - minY < 1e-9) {
      minY -= 1;
      maxY += 1;
    }
    final pad = (maxY - minY) * 0.1;
    minY = math.max(0, minY - pad);
    maxY += pad;
    final t0 = points.first.$1.millisecondsSinceEpoch.toDouble();
    final t1 = points.last.$1.millisecondsSinceEpoch.toDouble();
    double x(DateTime t) => t1 == t0 ? left + w / 2 : left + (t.millisecondsSinceEpoch - t0) / (t1 - t0) * w;
    double y(double v) => top + (1 - (v - minY) / (maxY - minY)) * h;

    final grid = Paint()
      ..color = textColor.withValues(alpha: 0.12)
      ..strokeWidth = 1;
    for (var i = 0; i <= 4; i++) {
      final v = minY + (maxY - minY) * i / 4;
      canvas.drawLine(Offset(left, y(v)), Offset(size.width - right, y(v)), grid);
      _paintText(canvas, fmtNum(v, 1), Offset(0, y(v) - 7), left - 6, TextAlign.right, textColor);
    }
    _paintText(canvas, formatShortDate(points.first.$1), Offset(left, size.height - bottom + 6), 60, TextAlign.left,
        textColor);
    if (points.length > 1) {
      _paintText(canvas, formatShortDate(points.last.$1), Offset(size.width - right - 60, size.height - bottom + 6), 60,
          TextAlign.right, textColor);
    }

    final path = Path();
    for (var i = 0; i < points.length; i++) {
      final o = Offset(x(points[i].$1), y(points[i].$2));
      if (i == 0) {
        path.moveTo(o.dx, o.dy);
      } else {
        path.lineTo(o.dx, o.dy);
      }
    }
    canvas.drawPath(
        path,
        Paint()
          ..color = color
          ..strokeWidth = 2.5
          ..style = PaintingStyle.stroke);
    final dot = Paint()..color = color;
    for (final p in points) {
      canvas.drawCircle(Offset(x(p.$1), y(p.$2)), 3.5, dot);
    }
  }

  @override
  bool shouldRepaint(_LineChartPainter old) => old.points != points || old.color != color;
}

class SimpleBarChart extends StatelessWidget {
  final List<double> values;
  final List<String> labels;
  final Color color;
  const SimpleBarChart({super.key, required this.values, required this.labels, required this.color});

  @override
  Widget build(BuildContext context) => SizedBox(
        height: 180,
        width: double.infinity,
        child: CustomPaint(painter: _BarChartPainter(values, labels, color, Theme.of(context).colorScheme.onSurface)),
      );
}

class _BarChartPainter extends CustomPainter {
  final List<double> values;
  final List<String> labels;
  final Color color, textColor;
  _BarChartPainter(this.values, this.labels, this.color, this.textColor);

  @override
  void paint(Canvas canvas, Size size) {
    if (values.isEmpty) return;
    const top = 18.0, bottom = 22.0;
    final maxV = math.max(values.reduce(math.max), 1e-9);
    final slot = size.width / values.length;
    final h = size.height - top - bottom;
    final paint = Paint()..color = color;
    for (var i = 0; i < values.length; i++) {
      final bh = values[i] / maxV * h;
      final rect = Rect.fromLTWH(i * slot + slot * 0.18, top + h - bh, slot * 0.64, bh);
      canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(4)), paint);
      if (values[i] > 0) {
        _paintText(canvas, _compact(values[i]), Offset(i * slot, top + h - bh - 15), slot, TextAlign.center, textColor);
      }
      _paintText(canvas, labels[i], Offset(i * slot, size.height - bottom + 6), slot, TextAlign.center, textColor);
    }
  }

  String _compact(double v) => v >= 10000 ? '${fmtNum(v / 1000, 0)}k' : v >= 1000 ? '${fmtNum(v / 1000, 1)}k' : fmtNum(v, 0);

  @override
  bool shouldRepaint(_BarChartPainter old) => old.values != values;
}
