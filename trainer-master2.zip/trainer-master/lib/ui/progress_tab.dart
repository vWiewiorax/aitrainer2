import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../data/dates.dart';
import '../data/models.dart';
import '../data/stats.dart';
import '../data/store.dart';
import 'exercise_screen.dart';
import 'widgets.dart';

class ProgressTab extends StatelessWidget {
  const ProgressTab({super.key});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final sets = store.allSets;
    if (sets.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Postępy')),
        body: const EmptyHint('Zapisz pierwszy trening, a tutaj pojawią się statystyki, rekordy i wykresy.',
            icon: Icons.insights),
      );
    }
    final now = today();
    final weekStart = startOfWeek(now);
    final weekKey = dateKey(weekStart);
    final monthKey = dateKey(DateTime(now.year, now.month));
    final dates = store.workoutDates;
    final setsPerDay = <String, int>{};
    for (final s in sets) {
      setsPerDay[s.date] = (setsPerDay[s.date] ?? 0) + 1;
    }

    final weekVolumes = <double>[];
    final weekLabels = <String>[];
    for (var i = 7; i >= 0; i--) {
      final start = DateTime(weekStart.year, weekStart.month, weekStart.day - 7 * i);
      final from = dateKey(start), to = dateKey(DateTime(start.year, start.month, start.day + 7));
      weekVolumes.add(sets
          .where((s) => s.date.compareTo(from) >= 0 && s.date.compareTo(to) < 0)
          .fold(0.0, (a, s) => a + s.volume));
      weekLabels.add(formatShortDate(start));
    }

    final exercisesUsed = [for (final id in {for (final s in sets) s.exerciseId}) store.exercise(id)].whereType<Exercise>();
    final cutoff = dateKey(now.subtract(const Duration(days: 30)));
    final recentPrs = <(Exercise, WorkoutSet)>[];
    final best1rm = <(Exercise, ExerciseStats)>[];
    for (final ex in exercisesUsed) {
      final st = store.stats(ex);
      for (final s in st.sets) {
        if (st.prIds.contains(s.id) && s.date.compareTo(cutoff) >= 0) recentPrs.add((ex, s));
      }
      if (st.bestE1rm > 0) best1rm.add((ex, st));
    }
    recentPrs.sort((a, b) => compareSets(b.$2, a.$2));
    best1rm.sort((a, b) => b.$2.bestE1rm.compareTo(a.$2.bestE1rm));

    return Scaffold(
      appBar: AppBar(title: const Text('Postępy')),
      body: ListView(padding: const EdgeInsets.only(bottom: 32), children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
          child: GridView.count(
            crossAxisCount: 3,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 1.15,
            children: [
              StatCard('Treningi w tym tyg.', '${dates.where((d) => d.compareTo(weekKey) >= 0).length}'),
              StatCard('W tym miesiącu', '${dates.where((d) => d.compareTo(monthKey) >= 0).length}'),
              StatCard('Objętość (tydz.)', '${fmtNum(weekVolumes.last / 1000, 1)} t'),
            ],
          ),
        ),
        const SectionHeader('Objętość tygodniowa (kg)'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: SimpleBarChart(values: weekVolumes, labels: weekLabels, color: Theme.of(context).colorScheme.primary),
        ),
        const SectionHeader('Aktywność (12 tygodni)'),
        _Heatmap(weekStart: weekStart, setsPerDay: setsPerDay),
        SectionHeader('Rekordy z ostatnich 30 dni (${recentPrs.length})'),
        if (recentPrs.isEmpty) const EmptyHint('Brak nowych rekordów w tym miesiącu. Do dzieła!', icon: Icons.emoji_events),
        for (final (ex, s) in recentPrs.take(15))
          ListTile(
            leading: const Icon(Icons.emoji_events, color: Colors.amber),
            title: Text(ex.name),
            subtitle: Text(formatDay(parseDateKey(s.date))),
            trailing: Text(formatSet(ex, s), style: const TextStyle(fontWeight: FontWeight.bold)),
            onTap: () => openExercise(context, ex.id, tab: ExerciseTab.graph),
          ),
        const SectionHeader('Szacowany 1RM'),
        for (final (ex, st) in best1rm.take(12))
          ListTile(
            leading: CategoryAvatar(ex.category),
            title: Text(ex.name),
            subtitle: Text('najlepsza seria: ${formatSet(ex, st.bestE1rmSet!)}'),
            trailing: Text('${fmtNum(st.bestE1rm, 1)} kg', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            onTap: () => openExercise(context, ex.id, tab: ExerciseTab.graph),
          ),
      ]),
    );
  }
}

class _Heatmap extends StatelessWidget {
  final DateTime weekStart;
  final Map<String, int> setsPerDay;
  const _Heatmap({required this.weekStart, required this.setsPerDay});

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.primary;
    final now = today();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Column(children: [
          for (final d in weekdayShort)
            SizedBox(height: 20, child: Text(d, style: const TextStyle(fontSize: 10, color: Colors.white54))),
        ]),
        const SizedBox(width: 6),
        for (var col = 0; col < 12; col++)
          Expanded(
            child: Column(children: [
              for (var row = 0; row < 7; row++)
                Builder(builder: (_) {
                  final day = DateTime(weekStart.year, weekStart.month, weekStart.day - 7 * (11 - col) + row);
                  final n = setsPerDay[dateKey(day)] ?? 0;
                  return Container(
                    height: 16,
                    margin: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(3),
                      color: day.isAfter(now)
                          ? Colors.transparent
                          : n == 0
                              ? Colors.white10
                              : color.withValues(alpha: math.min(1, 0.35 + n / 25)),
                    ),
                  );
                }),
            ]),
          ),
      ]),
    );
  }
}
